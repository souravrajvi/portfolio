## Packages
prismjs | Syntax highlighting for the code-like content
framer-motion | Smooth transitions between "tabs" and sections
lucide-react | Icons for the file explorer and UI elements

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  mono: ["'Fira Code'", "'JetBrains Mono'", "monospace"],
  sans: ["'Inter'", "sans-serif"],
}
